<?php include('includes/server.php');?>

<?php
if(!isset($_SESSION['username'])){
header('location:login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Gallery for <?php echo $_SESSION['username'];?></title>
<link rel="stylesheet" href="includes/style.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
Welcome <?php echo $_SESSION['username'];?>
<br>
Images
<br>
<div class="container">
<?php while($row = mysqli_fetch_assoc($result)){
echo "<table>";
echo"<td>" ."<b>". "posted by:". "</b>" . " ". $row['poster'] . "<br>" . "</td>";
echo "<td>"."<b>".  "Tilted:". "</b>" . " " .$row['title'].  "<br>" . "</td>";
echo "<td>" ."<b>" . "Description:" . "</b>" . " ". $row['descr']. "<br>" ."</td>";
echo "<table>";
echo"<img width='250' height='200' src='img/".$row['image']."' >"."<br>";
echo "<hr>";
}
?></div>
<p> 
<form method="POST" action="index.php" enctype="multipart/form-data">
<input type="text" name="poster" placeholder="Uploaded by?"/><br>
<input type="text" name="title" placeholder="Image Title"/><br>
<input type="text" name="descr" placeholder="Image Description"/><br>
<input type="file" name="image" /><br>
<button name="post" class="post">Upload</button>
</p>
</form>
</body>
</html>