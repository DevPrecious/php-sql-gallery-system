<?php

$conn = mysqli_connect('localhost', 'root','','Sgallery');
if(!$conn){
die("Error");
}

session_start();
$username = "";

if(isset($_POST['submit'])){
$username = mysqli_real_escape_string($conn, $_POST['username']);
$email = mysqli_real_escape_string($conn, $_POST['email']);
$password = mysqli_real_escape_string($conn, $_POST['password']);

if(empty($username)){
echo "Username is required"."<br>";
}
if(empty($email)){
echo "Email is required"."<br>";
}
if(empty($password)){
echo "Password is required"."<br>";
}

$sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$password')";
mysqli_query($conn, $sql);
$_SESSION['username'] = $username;
header('location : index.php');

}

//login

if(isset($_POST['login'])){
$username = mysqli_real_escape_string($conn, $_POST['username']);
$password = mysqli_real_escape_string($conn, $_POST['password']);

if(empty($username)){
echo "Username is required" . "<br>";
}
if(empty($password)){
echo "Password is required" . "<br>";
}

$sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
$result = mysqli_query($conn, $sql);
$_SESSION['username']=$username;
if(mysqli_num_rows($result)== 1){
header('location:index.php');
}else{
echo "User not found";
}
}

//post

$msg= "";

if(isset($_POST['post'])){

$poster = $_POST['poster'];
$title = $_POST['title'];
$descr = $_POST['descr'];

$image = $_FILES['image']['name'];

$target = "img/". basename($image);

$sql = "INSERT INTO images (poster, title, descr, image) VALUES ('$poster', '$title', '$descr', '$image')";
mysqli_query($conn, $sql);

if(move_uploaded_file($_FILES['image']['tmp_name'], $target)){
$msg = "Upload Successful";
}else{
$msg = "Upload Failed";
}
}
$result = mysqli_query($conn, "SELECT * FROM images");
