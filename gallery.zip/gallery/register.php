<?php include('includes/server.php');?>
<!DOCTYPE html>
<html>
<head>
<title></title>
</head>
<body>
<form action="index.php" method="post">
<input type="text" name="username" placeholder="Username"/><br>
<input type="email" name="email" placeholder="Email " /><br>
<input type="password" name="password" placeholder="password " /><br>
<button name="submit">Submit</button><br>
<a href="login.php">Already Own An account?</a>
</form>
</body>
</html>