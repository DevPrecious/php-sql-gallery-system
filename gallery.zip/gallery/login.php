<?php include('includes/server.php');?>
<!DOCTYPE html>
<html>
<head>
<title></title>
</head>
<body>
<form action="index.php" method="post">
<input type="text" name="username" placeholder="Username"/><br>
<input type="password" name="password" placeholder="Password" /><br>
<button name="login">Login</button><br>
<a href="register.php">Register now</a>
</form>
</body>
</html>